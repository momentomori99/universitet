data = load('137cs.asc')


